﻿var context;
var hostweburl;
function getQueryStringParameter(urlParameterKey) {
    var params = document.URL.split('?')[1].split('&');
    var strParams = '';
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split('=');
        if (singleParam[0] == urlParameterKey)
            return singleParam[1];
    }
}

function onQuerySucceeded(sender, args) {
    var listItemInfo = '';
    var listItemEnumerator = collListItem.getEnumerator();

    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        listItemInfo += '\nID: ' + oListItem.get_id() +
            '\nTitle: ' + oListItem.get_item('Title') +
            '\nValue: ' + oListItem.get_item('Value');
    }

    alert(listItemInfo.toString());
}

function onQueryFailed(sender, args) {
    alert('Request failed. ' + args.get_message() +
        '\n' + args.get_stackTrace());
}

function getRedirectUrl() {
    var appweburl = decodeURIComponent(getQueryStringParameter("SPAppWebUrl"));
    // var getRedirectUrl = appweburl + "/_api/SP.AppContextSite(@target)/web/lists/getbytitle('GlobalConfiguration')/items?@target='https://vsureshk.sharepoint.com/sites/Configuration'";
    //var hostweburl = 'https://vsureshk.sharepoint.com/sites/Configuration';
    var context = new SP.ClientContext(appweburl);
    var factory = new SP.ProxyWebRequestExecutorFactory(appweburl);
    context.set_webRequestExecutorFactory(factory);
    var appContextSite = new SP.AppContextSite(context, hostweburl);

    this.web = appContextSite.get_web();
    context.load(this.web);

    var oList = web.get_lists().getByTitle('ConfigurationList');

    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('');
    this.collListItem = oList.getItems(camlQuery);

    context.load(collListItem);
    context.executeQueryAsync(
        Function.createDelegate(this, this.onQuerySucceeded),
        Function.createDelegate(this, this.onQueryFailed)
    );

}

$(document).ready(function () {
    var appweburl = decodeURIComponent(getQueryStringParameter("SPAppWebUrl"));
    hostweburl = decodeURIComponent(getQueryStringParameter("SPHostUrl"));
    var layoutsRoot =  appweburl+ '/_layouts/15/';
//$.getScript(layoutsRoot + 'SP.Runtime.js',
      // function () {
           $.getScript(layoutsRoot + 'SP.js',
                function () {
                    $.getScript(layoutsRoot + 'SP.RequestExecutor.js', function () {
                        getRedirectUrl();
                    });
                });
      // });
});


//<style unselectable="on">
//#pageContentTitle {
//    display:none;
//}
//</style>
