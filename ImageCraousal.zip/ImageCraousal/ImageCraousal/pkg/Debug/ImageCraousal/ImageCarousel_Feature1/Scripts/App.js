﻿'use strict';

var context = SP.ClientContext.get_current();
var user = context.get_web().get_currentUser();

// This code runs when the DOM is ready and creates a context object which is needed to use the SharePoint object model
//$(document).ready(function () {
//    getUserName();
//});

//// This function prepares, loads, and then executes a SharePoint query to get the current users information
//function getUserName() {
//    context.load(user);
//    context.executeQueryAsync(onGetUserNameSuccess, onGetUserNameFail);
//}

//// This function is executed if the above call is successful
//// It replaces the contents of the 'message' element with the user name
//function onGetUserNameSuccess() {
//    $('#message').text('Hello ' + user.get_title());
//}

//// This function is executed if the above call fails
//function onGetUserNameFail(sender, args) {
//    alert('Failed to get user name. Error:' + args.get_message());
//}

var hostweburl;
var appweburl;
var web;
var currentUser;
var factory;
var appContextSite;
var imageList;
var imageItems;
var ImageCarouselType;

function getQueryStringParameter(param) {
    var params = document.URL.split("?")[1].split("&");
    var strParams = "";
    for (var i = 0; i < params.length; i = i + 1) {
        var singleParam = params[i].split("=");
        if (singleParam[0] == param) {
            return singleParam[1];
        }
    }
}

function getcurrentcontext() {
    hostweburl = decodeURIComponent(getQueryStringParameter('SPHostUrl'));
    appweburl = decodeURIComponent(getQueryStringParameter('SPAppWebUrl'));
    ImageCarouselType = decodeURIComponent(getQueryStringParameter('PageName'));
    var scriptbase = hostweburl + '/_layouts/15/';

    //Register the required js files
    //$.getScript(scriptbase + 'SP.Runtime.js',
    //function () {
    //    $.getScript(scriptbase + 'SP.js',
    //     function () {
    //$.getScript(scriptbase + 'SP.UserProfiles.js',
    //  function () {
    $.getScript(scriptbase + 'SP.RequestExecutor.js', getContextLoadUser);
    //});
    //     });
    //});
}

function getContextLoadUser() {
    //Get the ProxyWebRequestExecutorFactory
    factory = new SP.ProxyWebRequestExecutorFactory(appweburl);

    //Assign the factory to the client context.
    context.set_webRequestExecutorFactory(factory);

    //Get the app context of the Host Web using the client context 
    appContextSite = new SP.AppContextSite(context, hostweburl);

    currentUser = context.get_web().get_currentUser();
    context.load(currentUser);
    context.executeQueryAsync(getImageItems, errorHandler);
}

function getImageItems() {
    var queryValue = null;
    var camlQuery = new SP.CamlQuery();
    //currentUserName = currentUser.get_title();
    this.web = appContextSite.get_web();
    imageList = this.web.get_lists().getByTitle("ImageCarouselLibrary");
    if (ImageCarouselType === 'Home') {
        queryValue = "<View><Query><Where><Eq><FieldRef Name='Show'/><Value Type='Choice'>true</Value></Eq></Where><OrderBy><FieldRef Name='Order0'/></OrderBy></Query><RowLimit>10</RowLimit></View>";
    }
    else
        queryValue = "<View><Query><Where><Eq><FieldRef Name='Show'/><Value Type='Choice'>true</Value></Eq></Where><OrderBy><FieldRef Name='Order0'/></OrderBy></Query><RowLimit>5</RowLimit></View>";
    camlQuery.set_viewXml(queryValue);
    this.imageItems = imageList.getItems(camlQuery);
    context.load(this.imageItems);
    context.executeQueryAsync(Function.createDelegate(this, bindItemsToUl), Function.createDelegate(this, errorHandler));
}

function errorHandler(data, errorCode, errorMessage) {
    $("#message").text(errorMessage);
}

function bindItemsToUl() {
    var ohtml = '<div id="banner-fade"><ul class="bjqs">';
    var listItemEnumerator = this.imageItems.getEnumerator();
    var oListItem;

    while (listItemEnumerator.moveNext()) {
        oListItem = listItemEnumerator.get_current();
        var ihtml = '<img src="' + oListItem.get_item('FileRef') + '"/> ';
        var titleText = oListItem.get_item('Title');
        var shortDesc = '';
        if (ImageCarouselType === 'Home')
            shortDesc = oListItem.get_item('ShortDescription');
        var MainDesc = oListItem.get_item('Description');

        if (titleText !== null) {
            ihtml = ihtml + '<div class="titlediv">';
            ihtml = ihtml + '<div class="maintitlediv">' + titleText + '</div>';
            if (ImageCarouselType === 'Home' && shortDesc !== null) {
                ihtml = ihtml + '<div class="titledescdiv">' + oListItem.get_item('ShortDescription') + '</div>';
            }
            ihtml = ihtml + '</div>';
        }
        if (ImageCarouselType === 'Home' && MainDesc !== null) {
            ihtml = ihtml + '<div class="descdiv">' + oListItem.get_item('Description') + '</div>';
        }
        if (oListItem.get_item('NavigationLink') !== null) {
            ihtml = '<a href="' + oListItem.get_item('NavigationLink').get_url() + '" target="_Parent">' + ihtml + '</a>';
        }
        ohtml = ohtml + '<li>' + ihtml + '</li>';

    }
    ohtml = ohtml + '</ul></div>';

    $("#ImgCarouselcontainer").html(ohtml);

    $('#banner-fade').bjqs({
        height: 450,
        width: 960,
        responsive: true,
        animtype: 'slide'
    });
    if (ImageCarouselType === 'Donor') {
        $('.titlediv').addClass('bottomdiv');
    }
    $(".bjqs-next a img").css('transform', 'rotate(180deg)');
    /* Opera, Chrome, and Safari */
    $(".bjqs-next a img").css('WebkitTransform', 'rotate(180deg)');
    /* IE 9 */
    $(".bjqs-next a img").css('msTransform', 'rotate(180deg)');

    //while (listItemEnumerator.moveNext()) {
    //    oListItem = listItemEnumerator.get_current();


    //}

}

$(document).ready(function () {

    getcurrentcontext();
});

//document.getElementById("myDIV").style.transform = "rotate(180deg)";
///* Opera, Chrome, and Safari */
//document.getElementById("myDIV").style.WebkitTransform = "rotate(180deg)";
///* IE 9 */
//document.getElementById("myDIV").style.msTransform = "rotate(180deg)";