﻿"use strict";
$.fn.imagecarousel = function (options) {
    var defaults = {

        // w + h to enforce consistency
        width: 700,
        height: 300,

        animduration: 450,      // length of transition
        animspeed: 2000,     // delay between transitions
        automatic: true,     // enable/disable automatic slide rotation

        showcontrols: true,
        showtitle: true,
        showdescription: true,
        shownextprev: true,

        // interaction values
        keyboardnav: true,     // enable/disable keyboard navigation
        hoverpause: true,     // enable/disable pause slides on hover

        randomstart: false,     // start from a random slide
    };
    var settings = $.extend({}, defaults, options);

    var $wrapper = this,
           $slider = $wrapper.find('ul.bjqs'),
           $slides = $slider.children('li');

    var init = function () {

        // differentiate slider li from content li
        $slides.addClass('bjqs-slide');

        // conf dimensions, responsive

        conf_responsive();


        // configurations only avaliable if more than 1 slide
        if (state.slidecount > 1) {

            // enable random start
            if (settings.randomstart) {
                conf_random();
            }

            // create and show controls
            if (settings.showcontrols) {
                //conf_controls();
            }

            // create and show markers
            if (settings.showmarkers) {
                conf_markers();
            }

            // enable slidenumboard navigation
            if (settings.keyboardnav) {
                conf_keynav();
            }

            // enable pause on hover
            if (settings.hoverpause && settings.automatic) {
                conf_hoverpause();
            }

            // conf slide animation
            if (settings.animtype === 'slide') {
                conf_slide();
            }

        } else {
            // Stop automatic animation, because we only have one slide! 
            settings.automatic = false;
        }

        if (settings.usecaptions) {
            conf_captions();
        }

        // TODO: need to accomodate random start for slide transition setting
        if (settings.animtype === 'slide' && !settings.randomstart) {
            state.currentindex = 1;
            state.currentslide = 2;
        }

        // slide components are hidden by default, show them now
        $slider.show();
        $slides.eq(state.currentindex).show();

        // Finally, if automatic is set to true, kick off the interval
        if (settings.automatic) {
            state.interval = setInterval(function () {
                go(vars.fwd, false);
            }, settings.animspeed);
        }

    };

    var conf_responsive = function () {

        responsive.width = $wrapper.outerWidth();
        responsive.ratio = responsive.width / settings.width,
        responsive.height = settings.height * responsive.ratio;

        if (settings.animtype === 'fade') {

            // initial setup
            $slides.css({
                'height': settings.height,
                'width': '100%'
            });
            $slides.children('img').css({
                'height': settings.height,
                'width': '100%'
            });
            $slider.css({
                'height': settings.height,
                'width': '100%'
            });
            $wrapper.css({
                'height': settings.height,
                'max-width': settings.width,
                'position': 'relative'
            });

            if (responsive.width < settings.width) {

                $slides.css({
                    'height': responsive.height
                });
                $slides.children('img').css({
                    'height': responsive.height
                });
                $slider.css({
                    'height': responsive.height
                });
                $wrapper.css({
                    'height': responsive.height
                });

            }

            $(window).resize(function () {

                // calculate and update dimensions
                responsive.width = $wrapper.outerWidth();
                responsive.ratio = responsive.width / settings.width,
                responsive.height = settings.height * responsive.ratio;

                $slides.css({
                    'height': responsive.height
                });
                $slides.children('img').css({
                    'height': responsive.height
                });
                $slider.css({
                    'height': responsive.height
                });
                $wrapper.css({
                    'height': responsive.height
                });

            });

        }

        if (settings.animtype === 'slide') {

            // initial setup
            $slides.css({
                'height': settings.height,
                'width': settings.width
            });
            $slides.children('img').css({
                'height': settings.height,
                'width': settings.width
            });
            $slider.css({
                'height': settings.height,
                'width': settings.width * settings.slidecount
            });
            $wrapper.css({
                'height': settings.height,
                'max-width': settings.width,
                'position': 'relative'
            });

            if (responsive.width < settings.width) {

                $slides.css({
                    'height': responsive.height
                });
                $slides.children('img').css({
                    'height': responsive.height
                });
                $slider.css({
                    'height': responsive.height
                });
                $wrapper.css({
                    'height': responsive.height
                });

            }

            $(window).resize(function () {

                // calculate and update dimensions
                responsive.width = $wrapper.outerWidth(),
                responsive.ratio = responsive.width / settings.width,
                responsive.height = settings.height * responsive.ratio;

                $slides.css({
                    'height': responsive.height,
                    'width': responsive.width
                });
                $slides.children('img').css({
                    'height': responsive.height,
                    'width': responsive.width
                });
                $slider.css({
                    'height': responsive.height,
                    'width': responsive.width * settings.slidecount
                });
                $wrapper.css({
                    'height': responsive.height
                });
                $canvas.css({
                    'height': responsive.height,
                    'width': responsive.width
                });

                resize_complete(function () {
                    go(false, state.currentslide);
                }, 200, "some unique string");

            });

        }

    };

    var resize_complete = (function () {

        var timers = {};

        return function (callback, ms, uniqueId) {
            if (!uniqueId) {
                uniqueId = "Don't call this twice without a uniqueId";
            }
            if (timers[uniqueId]) {
                clearTimeout(timers[uniqueId]);
            }
            timers[uniqueId] = setTimeout(callback, ms);
        };

    })();

    var conf_markers = function () {

        // create a wrapper for our markers
        $m_wrapper = $('<ol class="bjqs-markers"></ol>');

        // for every slide, create a marker
        $.each($slides, function (key, slide) {

            var slidenum = key + 1,
                gotoslide = key + 1;

            if (settings.animtype === 'slide') {
                // + 2 to account for clones
                gotoslide = key + 2;
            }
            var marker = $('<li><a href="#"></a></li>');
            //var marker = $('<li><a href="#">'+ slidenum +'</a></li>');

            // set the first marker to be active
            if (slidenum === state.currentslide) { marker.addClass('active-marker'); }

            // bind the click event
            marker.on('click', 'a', function (e) {
                e.preventDefault();
                if (!state.animating && state.currentslide !== gotoslide) {
                    go(false, gotoslide);
                }
            });

            // add the marker to the wrapper
            marker.appendTo($m_wrapper);

        });

        $m_wrapper.appendTo($wrapper);
        $m_markers = $m_wrapper.find('li');

        // center the markers
        if (settings.centermarkers) {
            $m_wrapper.addClass('h-centered');
            var offset = (settings.width - $m_wrapper.width()) / 2;
            $m_wrapper.css('left', offset);
        }

    };



};

